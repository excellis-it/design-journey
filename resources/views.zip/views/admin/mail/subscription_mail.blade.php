


<img src="{{ asset('frontend_assets/assets/images/logo.png')}}" alt="logo" border="0" style="object-fit: contain; width: 100px; height: 50px;font-family: Montserrat, sans-serif; display:inline-block;" />


{!! $content !!} 


Thanks,<br>
{{ config('app.name') }}
