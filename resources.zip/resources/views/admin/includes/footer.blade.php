{{-- <footer class="main-footer">
    <div class="footer-left">
        Copyright © 2023
        <div class="bullet"></div>
        <a target="_blank" href="{{ route('home') }}"></a>
    </div>
    <div class="footer-right"></div>
</footer>
 --}}
